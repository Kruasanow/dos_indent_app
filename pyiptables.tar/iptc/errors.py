# -*- coding: utf-8 -*-


class XTablesError(Exception):
    """Raised when an xtables call fails for some reason."""


__all__ = ['XTablesError']
