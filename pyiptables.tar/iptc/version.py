# -*- coding: utf-8 -*-

__pkgname__ = "python-iptables"
__version__ = "1.0.2-dev"
